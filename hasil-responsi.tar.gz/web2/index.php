<?php

$nama = "Nurul Maftuhah";
$nim  = "H1H024002";

?>

<!DOCTYPE html>
<html>
<head>
    <title>Web 2</title>
</head>
<body>

<h1>WEB SERVER 2</h1>

<hr>

<p>
Nama Praktikan:
<strong><?= $nama ?></strong>
</p>

<p>
NIM:
<strong><?= $nim ?></strong>
</p>

<p>
Container:
<strong>WEB-WEB</strong>
</p>

</body>
</html>
